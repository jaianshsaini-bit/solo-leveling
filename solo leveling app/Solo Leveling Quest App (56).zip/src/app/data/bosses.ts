export interface Item {
  id: string;
  name: string;
  type: 'weapon' | 'armor' | 'accessory' | 'consumable';
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
  stats?: {
    strength?: number;
    agility?: number;
    vitality?: number;
    intelligence?: number;
    sense?: number;
  };
  description: string;
  icon: string;
  droppedBy?: string;
}

export interface Boss {
  id: string;
  name: string;
  level: number;
  hp: number;
  maxHp: number;
  attack: number;
  defense: number;
  image: string;
  description: string;
  unlockLevel: number;
  drops: Item[];
  defeated: boolean;
}

export const bossItems: Item[] = [
  {
    id: 'demon-sword',
    name: "Demon King's Sword",
    type: 'weapon',
    rarity: 'legendary',
    stats: { strength: 20, agility: 10 },
    description: 'A cursed blade wielded by the Demon King',
    icon: '⚔️',
  },
  {
    id: 'ice-dagger',
    name: 'Frost Fang Dagger',
    type: 'weapon',
    rarity: 'epic',
    stats: { agility: 15, intelligence: 8 },
    description: 'Dagger infused with eternal ice',
    icon: '🗡️',
  },
  {
    id: 'stone-shield',
    name: 'Stone Guardian Shield',
    type: 'armor',
    rarity: 'rare',
    stats: { vitality: 18, strength: 5 },
    description: 'Shield blessed by ancient guardians',
    icon: '🛡️',
  },
  {
    id: 'shadow-armor',
    name: 'Shadow Monarch Armor',
    type: 'armor',
    rarity: 'legendary',
    stats: { vitality: 25, intelligence: 15, agility: 15 },
    description: 'Armor forged from pure darkness',
    icon: '🎽',
  },
  {
    id: 'rage-ring',
    name: 'Ring of Berserker Rage',
    type: 'accessory',
    rarity: 'epic',
    stats: { strength: 12, vitality: 8 },
    description: 'Increases combat power dramatically',
    icon: '💍',
  },
  {
    id: 'mana-crystal',
    name: 'Pure Mana Crystal',
    type: 'accessory',
    rarity: 'legendary',
    stats: { intelligence: 20, sense: 15 },
    description: 'Crystal containing immense magical power',
    icon: '💎',
  },
];

export const bosses: Boss[] = [
  {
    id: 'stone-golem',
    name: 'Stone Golem',
    level: 3,
    hp: 500,
    maxHp: 500,
    attack: 30,
    defense: 20,
    image: '🗿',
    description: 'A massive golem made of ancient stone',
    unlockLevel: 3,
    drops: [bossItems[2]], // Stone Shield
    defeated: false,
  },
  {
    id: 'ice-queen',
    name: 'Ice Queen',
    level: 5,
    hp: 800,
    maxHp: 800,
    attack: 45,
    defense: 25,
    image: '❄️',
    description: 'Ruler of the frozen wasteland',
    unlockLevel: 5,
    drops: [bossItems[1]], // Ice Dagger
    defeated: false,
  },
  {
    id: 'berserker',
    name: 'Crimson Berserker',
    level: 8,
    hp: 1200,
    maxHp: 1200,
    attack: 60,
    defense: 30,
    image: '👹',
    description: 'A warrior consumed by rage',
    unlockLevel: 8,
    drops: [bossItems[4]], // Rage Ring
    defeated: false,
  },
  {
    id: 'demon-king',
    name: 'Demon King',
    level: 15,
    hp: 2000,
    maxHp: 2000,
    attack: 80,
    defense: 40,
    image: '👿',
    description: 'The ruler of all demons',
    unlockLevel: 15,
    drops: [bossItems[0], bossItems[5]], // Demon Sword + Mana Crystal
    defeated: false,
  },
  {
    id: 'shadow-monarch',
    name: 'Ancient Shadow',
    level: 20,
    hp: 3000,
    maxHp: 3000,
    attack: 100,
    defense: 50,
    image: '🌑',
    description: 'The embodiment of darkness itself',
    unlockLevel: 20,
    drops: [bossItems[3]], // Shadow Armor
    defeated: false,
  },
];

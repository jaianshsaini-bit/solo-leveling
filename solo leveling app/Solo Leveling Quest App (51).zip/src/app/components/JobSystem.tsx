import { motion, AnimatePresence } from 'motion/react';
import { Sword, Wand2, Skull, Shield, Target, Crown, Lock, Check } from 'lucide-react';
import { useState } from 'react';

export interface JobClass {
  id: string;
  name: string;
  description: string;
  icon: any;
  statBonus: {
    strength: number;
    agility: number;
    vitality: number;
    intelligence: number;
    sense: number;
  };
  specialAbility: string;
  unlockRequirement: {
    level: number;
    description: string;
  };
  color: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

const jobClasses: JobClass[] = [
  {
    id: 'fighter',
    name: 'Fighter',
    description: 'Basic melee combat specialist',
    icon: Sword,
    statBonus: { strength: 5, agility: 2, vitality: 3, intelligence: 0, sense: 0 },
    specialAbility: 'Physical attacks deal 10% more damage',
    unlockRequirement: { level: 1, description: 'Available from start' },
    color: 'red',
    rarity: 'common',
  },
  {
    id: 'mage',
    name: 'Mage',
    description: 'Master of magical arts',
    icon: Wand2,
    statBonus: { strength: 0, agility: 2, vitality: 2, intelligence: 5, sense: 3 },
    specialAbility: 'Quest completion grants +20% bonus points',
    unlockRequirement: { level: 1, description: 'Available from start' },
    color: 'blue',
    rarity: 'common',
  },
  {
    id: 'assassin',
    name: 'Assassin',
    description: 'Swift and deadly striker',
    icon: Target,
    statBonus: { strength: 3, agility: 6, vitality: 1, intelligence: 2, sense: 4 },
    specialAbility: 'Arise points generation increased by 50%',
    unlockRequirement: { level: 5, description: 'Reach Level 5' },
    color: 'purple',
    rarity: 'rare',
  },
  {
    id: 'tank',
    name: 'Tank',
    description: 'Impenetrable fortress',
    icon: Shield,
    statBonus: { strength: 4, agility: 1, vitality: 7, intelligence: 1, sense: 2 },
    specialAbility: 'HP penalty reduced to -10 per failed quest',
    unlockRequirement: { level: 5, description: 'Reach Level 5' },
    color: 'green',
    rarity: 'rare',
  },
  {
    id: 'necromancer',
    name: 'Necromancer',
    description: 'Commander of the dead',
    icon: Skull,
    statBonus: { strength: 2, agility: 3, vitality: 3, intelligence: 6, sense: 5 },
    specialAbility: 'All Arise abilities cost 25% less',
    unlockRequirement: { level: 10, description: 'Reach Level 10' },
    color: 'purple',
    rarity: 'epic',
  },
  {
    id: 'monarch',
    name: 'Shadow Monarch',
    description: 'Sovereign of Shadows',
    icon: Crown,
    statBonus: { strength: 8, agility: 8, vitality: 8, intelligence: 8, sense: 8 },
    specialAbility: 'All stats +50%, Double quest rewards, No HP penalties',
    unlockRequirement: { level: 20, description: 'Reach Level 20 and complete 100 quests' },
    color: 'gold',
    rarity: 'legendary',
  },
];

interface JobSystemProps {
  currentJob: string;
  playerLevel: number;
  totalQuestsCompleted: number;
  onChangeJob: (jobId: string) => void;
}

export function JobSystem({ currentJob, playerLevel, totalQuestsCompleted, onChangeJob }: JobSystemProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedJob, setSelectedJob] = useState<JobClass | null>(null);

  const currentJobData = jobClasses.find((j) => j.id === currentJob);

  const isJobUnlocked = (job: JobClass) => {
    if (job.id === 'monarch') {
      return playerLevel >= job.unlockRequirement.level && totalQuestsCompleted >= 100;
    }
    return playerLevel >= job.unlockRequirement.level;
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-slate-400';
      case 'rare': return 'text-blue-400';
      case 'epic': return 'text-purple-400';
      case 'legendary': return 'text-yellow-400';
      default: return 'text-slate-400';
    }
  };

  const getRarityBorder = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-slate-500/30';
      case 'rare': return 'border-blue-500/50';
      case 'epic': return 'border-purple-500/50';
      case 'legendary': return 'border-yellow-500/70';
      default: return 'border-slate-500/30';
    }
  };

  const getRarityGlow = (rarity: string) => {
    switch (rarity) {
      case 'common': return '0 0 10px rgba(148, 163, 184, 0.3)';
      case 'rare': return '0 0 20px rgba(59, 130, 246, 0.4)';
      case 'epic': return '0 0 30px rgba(168, 85, 247, 0.5)';
      case 'legendary': return '0 0 40px rgba(234, 179, 8, 0.6)';
      default: return 'none';
    }
  };

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setShowModal(true)}
        className="w-full border border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg"
        style={{
          boxShadow: currentJobData ? getRarityGlow(currentJobData.rarity) : '0 0 20px rgba(6, 182, 212, 0.1)',
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            {currentJobData && (
              <div className={`p-3 rounded-lg ${
                currentJobData.color === 'red' ? 'bg-red-500/20' :
                currentJobData.color === 'blue' ? 'bg-blue-500/20' :
                currentJobData.color === 'purple' ? 'bg-purple-500/20' :
                currentJobData.color === 'green' ? 'bg-green-500/20' :
                'bg-yellow-500/20'
              }`}>
                <currentJobData.icon className={`w-8 h-8 ${
                  currentJobData.color === 'red' ? 'text-red-400' :
                  currentJobData.color === 'blue' ? 'text-blue-400' :
                  currentJobData.color === 'purple' ? 'text-purple-400' :
                  currentJobData.color === 'green' ? 'text-green-400' :
                  'text-yellow-400'
                }`} />
              </div>
            )}
            <div className="text-left">
              <div className="text-xs text-slate-500 mb-1">CURRENT JOB</div>
              <h2 className={`text-2xl font-black ${getRarityColor(currentJobData?.rarity || 'common')}`}
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                {currentJobData?.name || 'No Job'}
              </h2>
              <p className="text-sm text-slate-400 mt-1">{currentJobData?.description}</p>
            </div>
          </div>
          <div className="text-right">
            <button className="px-4 py-2 bg-cyan-500 hover:bg-cyan-600 rounded-lg font-medium text-sm transition-colors"
              style={{
                boxShadow: '0 0 15px rgba(6, 182, 212, 0.4)',
              }}
            >
              Change Job
            </button>
          </div>
        </div>

        {currentJobData && (
          <div className="mt-4 p-3 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
            <p className="text-xs text-cyan-300">
              <strong>Special Ability:</strong> {currentJobData.specialAbility}
            </p>
          </div>
        )}
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowModal(false);
              setSelectedJob(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-cyan-500/30 rounded-lg p-6 max-w-5xl w-full max-h-[90vh] overflow-y-auto"
              style={{
                boxShadow: '0 0 50px rgba(6, 182, 212, 0.4)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="mb-6">
                <h2
                  className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400 mb-2"
                  style={{ fontFamily: 'Orbitron, sans-serif' }}
                >
                  JOB CHANGE
                </h2>
                <p className="text-slate-400">Select a new job class to enhance your abilities</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {jobClasses.map((job) => {
                  const Icon = job.icon;
                  const isUnlocked = isJobUnlocked(job);
                  const isCurrent = job.id === currentJob;

                  return (
                    <motion.div
                      key={job.id}
                      whileHover={isUnlocked ? { scale: 1.02 } : {}}
                      className={`p-5 rounded-lg border-2 ${getRarityBorder(job.rarity)} ${
                        isCurrent ? 'bg-cyan-500/10' :
                        isUnlocked ? 'bg-slate-800/50' : 'bg-slate-800/30'
                      } ${!isUnlocked && 'opacity-60'} cursor-pointer relative`}
                      style={isUnlocked ? {
                        boxShadow: getRarityGlow(job.rarity),
                      } : {}}
                      onClick={() => {
                        if (isUnlocked && !isCurrent) {
                          setSelectedJob(job);
                        }
                      }}
                    >
                      {isCurrent && (
                        <div className="absolute top-3 right-3 p-1.5 bg-cyan-500 rounded-full">
                          <Check className="w-4 h-4" />
                        </div>
                      )}

                      {!isUnlocked && (
                        <div className="absolute top-3 right-3 p-1.5 bg-slate-700 rounded-full">
                          <Lock className="w-4 h-4 text-slate-400" />
                        </div>
                      )}

                      <div className="flex items-start gap-4">
                        <div className={`p-3 rounded-lg ${
                          job.color === 'red' ? 'bg-red-500/20' :
                          job.color === 'blue' ? 'bg-blue-500/20' :
                          job.color === 'purple' ? 'bg-purple-500/20' :
                          job.color === 'green' ? 'bg-green-500/20' :
                          'bg-yellow-500/20'
                        }`}>
                          <Icon className={`w-8 h-8 ${
                            job.color === 'red' ? 'text-red-400' :
                            job.color === 'blue' ? 'text-blue-400' :
                            job.color === 'purple' ? 'text-purple-400' :
                            job.color === 'green' ? 'text-green-400' :
                            'text-yellow-400'
                          }`} />
                        </div>

                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className={`text-xl font-bold ${getRarityColor(job.rarity)}`}
                              style={{ fontFamily: 'Orbitron, sans-serif' }}
                            >
                              {job.name}
                            </h3>
                            <span className={`text-xs px-2 py-0.5 rounded uppercase ${getRarityColor(job.rarity)}`}
                              style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}
                            >
                              {job.rarity}
                            </span>
                          </div>
                          <p className="text-sm text-slate-400 mb-3">{job.description}</p>

                          {/* Stat Bonuses */}
                          <div className="mb-3">
                            <div className="text-xs text-cyan-400 font-semibold mb-1">STAT BONUSES</div>
                            <div className="grid grid-cols-2 gap-1 text-xs">
                              {Object.entries(job.statBonus).map(([stat, bonus]) => (
                                bonus > 0 && (
                                  <div key={stat} className="flex items-center justify-between">
                                    <span className="text-slate-400 capitalize">{stat}:</span>
                                    <span className="text-green-400 font-semibold">+{bonus}</span>
                                  </div>
                                )
                              ))}
                            </div>
                          </div>

                          {/* Special Ability */}
                          <div className="p-2 bg-cyan-500/10 rounded border border-cyan-500/30 mb-3">
                            <div className="text-xs text-cyan-400 font-semibold mb-0.5">SPECIAL ABILITY</div>
                            <p className="text-xs text-slate-300">{job.specialAbility}</p>
                          </div>

                          {/* Unlock Requirement */}
                          {!isUnlocked && (
                            <div className="p-2 bg-red-500/10 rounded border border-red-500/30">
                              <div className="text-xs text-red-400 font-semibold mb-0.5">LOCKED</div>
                              <p className="text-xs text-slate-400">{job.unlockRequirement.description}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              {selectedJob && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 p-4 bg-cyan-500/20 border-2 border-cyan-500/50 rounded-lg"
                >
                  <p className="text-center text-cyan-100 mb-3">
                    Change job to <strong>{selectedJob.name}</strong>?
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        onChangeJob(selectedJob.id);
                        setShowModal(false);
                        setSelectedJob(null);
                      }}
                      className="flex-1 px-6 py-3 bg-cyan-500 hover:bg-cyan-600 rounded-lg font-bold transition-colors"
                      style={{
                        boxShadow: '0 0 20px rgba(6, 182, 212, 0.5)',
                        fontFamily: 'Orbitron, sans-serif',
                      }}
                    >
                      CONFIRM
                    </button>
                    <button
                      onClick={() => setSelectedJob(null)}
                      className="flex-1 px-6 py-3 bg-slate-700 hover:bg-slate-600 rounded-lg font-bold transition-colors"
                      style={{ fontFamily: 'Orbitron, sans-serif' }}
                    >
                      CANCEL
                    </button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

import { motion, AnimatePresence } from 'motion/react';
import { Swords, Heart, Shield, Zap, X, Trophy } from 'lucide-react';
import { useState } from 'react';
import { Boss, Item } from '../data/bosses';
import { PlayerStats } from './StatsDisplay';

interface BossBattleProps {
  bosses: Boss[];
  playerLevel: number;
  playerStats: PlayerStats;
  equippedItems: { [key: string]: Item | null };
  onDefeatBoss: (bossId: string, drops: Item[]) => void;
}

export function BossBattle({ bosses, playerLevel, playerStats, equippedItems, onDefeatBoss }: BossBattleProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedBoss, setSelectedBoss] = useState<Boss | null>(null);
  const [inBattle, setInBattle] = useState(false);
  const [playerHp, setPlayerHp] = useState(100);
  const [bossHp, setBossHp] = useState(0);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [isPlayerTurn, setIsPlayerTurn] = useState(true);
  const [battleEnded, setBattleEnded] = useState(false);
  const [victory, setVictory] = useState(false);

  const getEquipmentBonus = () => {
    const bonus = { strength: 0, agility: 0, vitality: 0, intelligence: 0, sense: 0 };
    Object.values(equippedItems).forEach((item) => {
      if (item?.stats) {
        Object.entries(item.stats).forEach(([key, value]) => {
          bonus[key as keyof typeof bonus] += value || 0;
        });
      }
    });
    return bonus;
  };

  const getTotalStats = () => {
    const equipBonus = getEquipmentBonus();
    return {
      strength: playerStats.strength + equipBonus.strength,
      agility: playerStats.agility + equipBonus.agility,
      vitality: playerStats.vitality + equipBonus.vitality,
      intelligence: playerStats.intelligence + equipBonus.intelligence,
      sense: playerStats.sense + equipBonus.sense,
    };
  };

  const startBattle = (boss: Boss) => {
    setSelectedBoss(boss);
    setBossHp(boss.maxHp);
    setPlayerHp(100);
    setInBattle(true);
    setBattleLog(['Battle Started!', `You are facing ${boss.name}!`]);
    setIsPlayerTurn(true);
    setBattleEnded(false);
    setVictory(false);
  };

  const calculateDamage = (attacker: 'player' | 'boss') => {
    const totalStats = getTotalStats();
    
    if (attacker === 'player') {
      const baseDamage = totalStats.strength + totalStats.intelligence;
      const critChance = totalStats.agility / 100;
      const isCrit = Math.random() < critChance;
      const damage = isCrit ? baseDamage * 2 : baseDamage;
      return { damage: Math.floor(damage), isCrit };
    } else {
      const bossDamage = selectedBoss!.attack;
      const defense = totalStats.vitality;
      const actualDamage = Math.max(bossDamage - defense * 0.5, 5);
      return { damage: Math.floor(actualDamage), isCrit: false };
    }
  };

  const playerAttack = () => {
    if (!selectedBoss || battleEnded) return;

    const { damage, isCrit } = calculateDamage('player');
    const newBossHp = Math.max(bossHp - damage, 0);
    setBossHp(newBossHp);

    const log = isCrit 
      ? `💥 CRITICAL HIT! You dealt ${damage} damage!`
      : `⚔️ You attacked for ${damage} damage!`;
    
    setBattleLog((prev) => [...prev, log]);

    if (newBossHp <= 0) {
      setBattleLog((prev) => [...prev, '🎉 VICTORY! Boss defeated!']);
      setBattleEnded(true);
      setVictory(true);
      return;
    }

    setIsPlayerTurn(false);
    setTimeout(bossAttack, 1500);
  };

  const bossAttack = () => {
    if (!selectedBoss || battleEnded) return;

    const { damage } = calculateDamage('boss');
    const newPlayerHp = Math.max(playerHp - damage, 0);
    setPlayerHp(newPlayerHp);

    setBattleLog((prev) => [...prev, `👹 ${selectedBoss.name} attacked for ${damage} damage!`]);

    if (newPlayerHp <= 0) {
      setBattleLog((prev) => [...prev, '💀 DEFEAT! You have been slain...']);
      setBattleEnded(true);
      setVictory(false);
      return;
    }

    setIsPlayerTurn(true);
  };

  const handleVictory = () => {
    if (selectedBoss) {
      onDefeatBoss(selectedBoss.id, selectedBoss.drops);
      setInBattle(false);
      setSelectedBoss(null);
    }
  };

  const availableBosses = bosses.filter((b) => playerLevel >= b.unlockLevel && !b.defeated);
  const defeatedBosses = bosses.filter((b) => b.defeated);

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setShowModal(true)}
        className="w-full border-2 border-red-500/50 bg-gradient-to-r from-red-900/30 to-orange-900/30 backdrop-blur-sm p-6 rounded-lg"
        style={{
          boxShadow: '0 0 30px rgba(239, 68, 68, 0.3)',
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-red-500/20 rounded-lg">
              <Swords className="w-8 h-8 text-red-400" />
            </div>
            <div className="text-left">
              <h2
                className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400"
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                BOSS BATTLES
              </h2>
              <p className="text-sm text-slate-400">Challenge powerful enemies</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-red-400">{availableBosses.length}</div>
            <div className="text-xs text-slate-400">Available</div>
          </div>
        </div>
      </motion.button>

      <AnimatePresence>
        {showModal && !inBattle && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-red-500/30 rounded-lg p-6 max-w-5xl w-full max-h-[90vh] overflow-y-auto"
              style={{
                boxShadow: '0 0 50px rgba(239, 68, 68, 0.4)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2
                  className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-400"
                  style={{ fontFamily: 'Orbitron, sans-serif' }}
                >
                  BOSS BATTLES
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 hover:bg-red-500/10 rounded-lg transition-colors"
                >
                  <X className="w-6 h-6 text-red-400" />
                </button>
              </div>

              {/* Available Bosses */}
              <div className="mb-6">
                <h3 className="text-lg font-bold text-red-400 mb-3">AVAILABLE CHALLENGES</h3>
                {availableBosses.length === 0 ? (
                  <div className="text-center py-8 text-slate-500">
                    <p>No bosses available at your current level.</p>
                    <p className="text-sm mt-2">Keep leveling up to unlock more challenges!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {availableBosses.map((boss) => (
                      <motion.div
                        key={boss.id}
                        whileHover={{ scale: 1.02 }}
                        className="p-5 rounded-lg border-2 border-red-500/50 bg-slate-800/50 cursor-pointer"
                        style={{
                          boxShadow: '0 0 20px rgba(239, 68, 68, 0.3)',
                        }}
                        onClick={() => startBattle(boss)}
                      >
                        <div className="flex items-start gap-4">
                          <div className="text-6xl">{boss.image}</div>
                          <div className="flex-1">
                            <h4 className="text-xl font-bold text-red-400 mb-1">{boss.name}</h4>
                            <p className="text-sm text-slate-400 mb-3">{boss.description}</p>
                            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                              <div className="flex justify-between">
                                <span className="text-slate-500">Level:</span>
                                <span className="text-yellow-400 font-bold">{boss.level}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-500">HP:</span>
                                <span className="text-red-400 font-bold">{boss.maxHp}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-500">Attack:</span>
                                <span className="text-orange-400 font-bold">{boss.attack}</span>
                              </div>
                              <div className="flex justify-between">
                                <span className="text-slate-500">Defense:</span>
                                <span className="text-blue-400 font-bold">{boss.defense}</span>
                              </div>
                            </div>
                            <div className="p-2 bg-yellow-500/10 border border-yellow-500/30 rounded">
                              <div className="text-xs text-yellow-400 font-semibold mb-1">DROPS</div>
                              <div className="text-xs text-slate-300">
                                {boss.drops.map((item) => item.icon).join(' ')} {boss.drops.map((item) => item.name).join(', ')}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              {/* Defeated Bosses */}
              {defeatedBosses.length > 0 && (
                <div>
                  <h3 className="text-lg font-bold text-green-400 mb-3">DEFEATED BOSSES</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {defeatedBosses.map((boss) => (
                      <div
                        key={boss.id}
                        className="p-4 rounded-lg border border-green-500/30 bg-slate-800/30 text-center"
                      >
                        <div className="text-4xl mb-2 opacity-50">{boss.image}</div>
                        <div className="text-sm font-bold text-green-400">{boss.name}</div>
                        <div className="text-xs text-slate-500">Defeated</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}

        {/* Battle Screen */}
        {inBattle && selectedBoss && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black z-50 flex items-center justify-center p-4"
          >
            <div className="w-full max-w-4xl">
              {/* Battle Header */}
              <div className="text-center mb-8">
                <h2
                  className="text-4xl font-black text-red-400 mb-2"
                  style={{ fontFamily: 'Orbitron, sans-serif', textShadow: '0 0 20px rgba(239, 68, 68, 0.8)' }}
                >
                  BOSS BATTLE
                </h2>
                <p className="text-slate-400">{selectedBoss.name}</p>
              </div>

              {/* Battle Arena */}
              <div className="grid grid-cols-2 gap-8 mb-8">
                {/* Player */}
                <div className="border-2 border-cyan-500/50 bg-slate-900/50 p-6 rounded-lg">
                  <div className="text-center mb-4">
                    <div className="text-6xl mb-3">🧍</div>
                    <h3 className="text-xl font-bold text-cyan-400">PLAYER</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">HP:</span>
                      <span className="text-red-400 font-bold">{playerHp}/100</span>
                    </div>
                    <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-red-600 to-red-400"
                        animate={{ width: `${playerHp}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Boss */}
                <div className="border-2 border-red-500/50 bg-slate-900/50 p-6 rounded-lg">
                  <div className="text-center mb-4">
                    <div className="text-6xl mb-3">{selectedBoss.image}</div>
                    <h3 className="text-xl font-bold text-red-400">{selectedBoss.name}</h3>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-400">HP:</span>
                      <span className="text-red-400 font-bold">{bossHp}/{selectedBoss.maxHp}</span>
                    </div>
                    <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-red-600 to-red-400"
                        animate={{ width: `${(bossHp / selectedBoss.maxHp) * 100}%` }}
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Battle Log */}
              <div className="bg-slate-900/50 border border-cyan-500/30 rounded-lg p-4 mb-6 h-40 overflow-y-auto">
                {battleLog.map((log, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="text-sm text-cyan-100 mb-1"
                  >
                    {log}
                  </motion.div>
                ))}
              </div>

              {/* Battle Actions */}
              {!battleEnded ? (
                <div className="flex gap-4">
                  <button
                    onClick={playerAttack}
                    disabled={!isPlayerTurn}
                    className="flex-1 px-6 py-4 bg-red-600 hover:bg-red-700 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-lg font-bold text-lg transition-all"
                    style={{
                      boxShadow: isPlayerTurn ? '0 0 30px rgba(239, 68, 68, 0.6)' : 'none',
                      fontFamily: 'Orbitron, sans-serif',
                    }}
                  >
                    <div className="flex items-center justify-center gap-2">
                      <Zap className="w-6 h-6" />
                      <span>ATTACK</span>
                    </div>
                  </button>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  {victory ? (
                    <>
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-6xl mb-4"
                      >
                        🎉
                      </motion.div>
                      <h3 className="text-3xl font-bold text-green-400">VICTORY!</h3>
                      <p className="text-slate-400">You have defeated {selectedBoss.name}!</p>
                      <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                        <div className="text-yellow-400 font-semibold mb-2">REWARDS</div>
                        <div className="flex justify-center gap-4">
                          {selectedBoss.drops.map((item) => (
                            <div key={item.id} className="text-center">
                              <div className="text-3xl">{item.icon}</div>
                              <div className="text-xs text-slate-300 mt-1">{item.name}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                      <button
                        onClick={handleVictory}
                        className="px-8 py-4 bg-green-600 hover:bg-green-700 rounded-lg font-bold text-lg transition-all"
                        style={{
                          boxShadow: '0 0 30px rgba(34, 197, 94, 0.6)',
                          fontFamily: 'Orbitron, sans-serif',
                        }}
                      >
                        CLAIM REWARDS
                      </button>
                    </>
                  ) : (
                    <>
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="text-6xl mb-4"
                      >
                        💀
                      </motion.div>
                      <h3 className="text-3xl font-bold text-red-400">DEFEAT</h3>
                      <p className="text-slate-400">You have been defeated...</p>
                      <button
                        onClick={() => {
                          setInBattle(false);
                          setSelectedBoss(null);
                        }}
                        className="px-8 py-4 bg-slate-700 hover:bg-slate-600 rounded-lg font-bold text-lg transition-all"
                        style={{ fontFamily: 'Orbitron, sans-serif' }}
                      >
                        RETREAT
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Heart, Trophy, TrendingUp, AlertTriangle, RefreshCw, LogOut } from 'lucide-react';
import { QuestList, Quest } from './components/QuestList';
import { StatsDisplay, PlayerStats } from './components/StatsDisplay';
import { CameraCapture } from './components/CameraCapture';
import { DeathScreen } from './components/DeathScreen';
import { AriseFeature } from './components/AriseFeature';
import { JobSystem } from './components/JobSystem';
import { LoginScreen } from './components/LoginScreen';
import { Inventory } from './components/Inventory';
import { BossBattle } from './components/BossBattle';
import { Boss, Item, bosses as initialBosses } from './data/bosses';

interface GameState {
  hp: number;
  level: number;
  exp: number;
  stats: PlayerStats;
  availablePoints: number;
  arisePoints: number;
  quests: Quest[];
  lastQuestReset: string;
  activeAriseBuff: string | null;
  ariseBuffExpiry: number | null;
  currentJob: string;
  totalQuestsCompleted: number;
  inventory: Item[];
  equippedItems: { weapon: Item | null; armor: Item | null; accessory: Item | null };
  bosses: Boss[];
}

const initialQuests: Quest[] = [
  {
    id: '1',
    title: 'Morning Exercise',
    description: '30 minutes of physical training',
    type: 'exercise',
    points: 50,
    completed: false,
    verified: false,
  },
  {
    id: '2',
    title: 'Healthy Meal',
    description: 'Consume a nutritious meal',
    type: 'nutrition',
    points: 30,
    completed: false,
    verified: false,
  },
  {
    id: '3',
    title: 'Learn Something New',
    description: 'Study or read for 1 hour',
    type: 'learning',
    points: 40,
    completed: false,
    verified: false,
  },
  {
    id: '4',
    title: 'Evening Workout',
    description: 'Complete strength training routine',
    type: 'exercise',
    points: 50,
    completed: false,
    verified: false,
  },
];

const STORAGE_KEY = 'solo_leveling_state';
const USERS_KEY = 'solo_leveling_users';
const CURRENT_USER_KEY = 'solo_leveling_current_user';

function App() {
  const [currentUser, setCurrentUser] = useState<string | null>(() => {
    return localStorage.getItem(CURRENT_USER_KEY);
  });

  const [gameState, setGameState] = useState<GameState>(() => {
    const user = localStorage.getItem(CURRENT_USER_KEY);
    if (!user) return null as any;
    
    const saved = localStorage.getItem(`${STORAGE_KEY}_${user}`);
    if (saved) {
      return JSON.parse(saved);
    }
    return {
      hp: 100,
      level: 1,
      exp: 0,
      stats: {
        strength: 10,
        agility: 10,
        vitality: 10,
        intelligence: 10,
        sense: 10,
      },
      availablePoints: 0,
      arisePoints: 0,
      quests: initialQuests,
      lastQuestReset: new Date().toDateString(),
      activeAriseBuff: null,
      ariseBuffExpiry: null,
      currentJob: 'fighter',
      totalQuestsCompleted: 0,
      inventory: [],
      equippedItems: { weapon: null, armor: null, accessory: null },
      bosses: initialBosses,
    };
  });

  const [cameraOpen, setCameraOpen] = useState(false);
  const [currentQuestId, setCurrentQuestId] = useState<string | null>(null);
  const [showWarning, setShowWarning] = useState(false);

  // Handle Login
  const handleLogin = (username: string, password: string) => {
    const usersData = localStorage.getItem(USERS_KEY);
    const users = usersData ? JSON.parse(usersData) : {};
    
    if (!users[username]) {
      // Create new user
      users[username] = { password, createdAt: new Date().toISOString() };
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    } else if (users[username].password !== password) {
      alert('Incorrect password!');
      return;
    }
    
    localStorage.setItem(CURRENT_USER_KEY, username);
    setCurrentUser(username);
    
    // Load user's game state
    const saved = localStorage.getItem(`${STORAGE_KEY}_${username}`);
    if (saved) {
      setGameState(JSON.parse(saved));
    } else {
      setGameState({
        hp: 100,
        level: 1,
        exp: 0,
        stats: {
          strength: 10,
          agility: 10,
          vitality: 10,
          intelligence: 10,
          sense: 10,
        },
        availablePoints: 0,
        arisePoints: 0,
        quests: initialQuests,
        lastQuestReset: new Date().toDateString(),
        activeAriseBuff: null,
        ariseBuffExpiry: null,
        currentJob: 'fighter',
        totalQuestsCompleted: 0,
        inventory: [],
        equippedItems: { weapon: null, armor: null, accessory: null },
        bosses: initialBosses,
      });
    }
  };

  const handleLogout = () => {
    localStorage.removeItem(CURRENT_USER_KEY);
    setCurrentUser(null);
    window.location.reload();
  };

  // Save to localStorage whenever gameState changes
  useEffect(() => {
    if (currentUser && gameState) {
      localStorage.setItem(`${STORAGE_KEY}_${currentUser}`, JSON.stringify(gameState));
    }
  }, [gameState, currentUser]);

  // Check for daily reset and HP penalties
  useEffect(() => {
    const today = new Date().toDateString();
    if (gameState.lastQuestReset !== today) {
      // Reset quests and apply HP penalty for incomplete quests
      const incompletedCount = gameState.quests.filter((q) => !q.completed).length;
      const hasMonarchBuff = gameState.activeAriseBuff === 'Monarch\'s Domain' && 
                            gameState.ariseBuffExpiry && 
                            Date.now() < gameState.ariseBuffExpiry;
      
      const hpPenalty = hasMonarchBuff ? 0 : incompletedCount * 20;
      
      setGameState((prev) => ({
        ...prev,
        hp: Math.max(0, prev.hp - hpPenalty),
        quests: initialQuests,
        lastQuestReset: today,
      }));

      if (hpPenalty > 0) {
        setShowWarning(true);
        setTimeout(() => setShowWarning(false), 5000);
      }
    }

    // Check if arise buff expired
    if (gameState.ariseBuffExpiry && Date.now() > gameState.ariseBuffExpiry) {
      setGameState((prev) => ({
        ...prev,
        activeAriseBuff: null,
        ariseBuffExpiry: null,
      }));
    }
  }, [gameState.lastQuestReset, gameState.quests, gameState.ariseBuffExpiry, gameState.activeAriseBuff]);

  const handleCapturePhoto = (questId: string) => {
    setCurrentQuestId(questId);
    setCameraOpen(true);
  };

  const handlePhotoCapture = (photoData: string) => {
    if (currentQuestId) {
      setGameState((prev) => ({
        ...prev,
        quests: prev.quests.map((q) =>
          q.id === currentQuestId ? { ...q, photoProof: photoData } : q
        ),
      }));
    }
    setCurrentQuestId(null);
  };

  const handleCompleteQuest = (questId: string) => {
    const quest = gameState.quests.find((q) => q.id === questId);
    if (!quest) return;

    const hasSoldierBuff = gameState.activeAriseBuff === 'Soldier\'s Will' && 
                          gameState.ariseBuffExpiry && 
                          Date.now() < gameState.ariseBuffExpiry;
    
    const pointsEarned = hasSoldierBuff ? quest.points * 2 : quest.points;
    const arisePointsEarned = 10;
    const newExp = gameState.exp + pointsEarned;
    const expNeeded = gameState.level * 100;

    let newLevel = gameState.level;
    let newAvailablePoints = gameState.availablePoints;
    let remainingExp = newExp;

    if (newExp >= expNeeded) {
      newLevel += 1;
      newAvailablePoints += 5;
      remainingExp = newExp - expNeeded;
    }

    setGameState((prev) => ({
      ...prev,
      quests: prev.quests.map((q) =>
        q.id === questId ? { ...q, completed: true, verified: true } : q
      ),
      exp: remainingExp,
      level: newLevel,
      availablePoints: newAvailablePoints,
      arisePoints: prev.arisePoints + arisePointsEarned,
      totalQuestsCompleted: prev.totalQuestsCompleted + 1,
    }));
  };

  const handleAddStat = (stat: keyof PlayerStats) => {
    if (gameState.availablePoints > 0) {
      setGameState((prev) => ({
        ...prev,
        stats: {
          ...prev.stats,
          [stat]: prev.stats[stat] + 1,
        },
        availablePoints: prev.availablePoints - 1,
      }));
    }
  };

  const handleActivateArise = (type: 'shadow' | 'soldier' | 'monarch') => {
    const costs = { shadow: 100, soldier: 150, monarch: 200 };
    const names = {
      shadow: 'Shadow Extraction',
      soldier: 'Soldier\'s Will',
      monarch: 'Monarch\'s Domain',
    };

    if (gameState.arisePoints >= costs[type]) {
      const expiryTime = Date.now() + 24 * 60 * 60 * 1000; // 24 hours
      setGameState((prev) => ({
        ...prev,
        arisePoints: prev.arisePoints - costs[type],
        activeAriseBuff: names[type],
        ariseBuffExpiry: expiryTime,
      }));
    }
  };

  const handleChangeJob = (jobId: string) => {
    setGameState((prev) => ({
      ...prev,
      currentJob: jobId,
    }));
  };

  const handleDefeatBoss = (bossId: string, drops: Item[]) => {
    setGameState((prev) => ({
      ...prev,
      bosses: prev.bosses.map((b) => (b.id === bossId ? { ...b, defeated: true } : b)),
      inventory: [...prev.inventory, ...drops],
    }));
  };

  const handleEquipItem = (item: Item) => {
    setGameState((prev) => ({
      ...prev,
      equippedItems: {
        ...prev.equippedItems,
        [item.type]: item,
      },
    }));
  };

  const handleUnequipItem = (slot: string) => {
    setGameState((prev) => ({
      ...prev,
      equippedItems: {
        ...prev.equippedItems,
        [slot]: null,
      },
    }));
  };

  const handleDeleteItem = (itemId: string) => {
    setGameState((prev) => ({
      ...prev,
      inventory: prev.inventory.filter((item) => item.id !== itemId),
    }));
  };

  const handleReset = () => {
    if (currentUser) {
      localStorage.removeItem(`${STORAGE_KEY}_${currentUser}`);
    }
    window.location.reload();
  };

  // Show login screen if no user logged in
  if (!currentUser) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  if (gameState.hp <= 0) {
    return <DeathScreen onReset={handleReset} />;
  }

  const expNeeded = gameState.level * 100;
  const expProgress = (gameState.exp / expNeeded) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 relative"
        >
          <button
            onClick={handleLogout}
            className="absolute right-0 top-0 p-2 hover:bg-red-500/10 rounded-lg transition-colors border border-red-500/30"
            title="Logout"
          >
            <LogOut className="w-5 h-5 text-red-400" />
          </button>
          <h1
            className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 mb-2"
            style={{
              fontFamily: 'Orbitron, sans-serif',
              textShadow: '0 0 40px rgba(6, 182, 212, 0.5)',
            }}
          >
            SOLO LEVELING SYSTEM
          </h1>
          <p className="text-slate-400" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            Hunter: {currentUser}
          </p>
        </motion.div>

        {/* Warning Alert */}
        {showWarning && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 bg-red-500/20 border border-red-500/50 rounded-lg flex items-center gap-3"
          >
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <p className="text-red-300 font-medium">
              HP penalty applied for incomplete quests!
            </p>
          </motion.div>
        )}

        {/* Player Status */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="border border-red-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg"
            style={{
              boxShadow: '0 0 20px rgba(239, 68, 68, 0.1)',
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Heart className="w-5 h-5 text-red-400" />
                <span className="text-slate-300 font-medium">HP</span>
              </div>
              <span className="text-2xl font-bold text-red-400">{gameState.hp}/100</span>
            </div>
            <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-red-600 to-red-400"
                initial={{ width: 0 }}
                animate={{ width: `${gameState.hp}%` }}
                style={{
                  boxShadow: '0 0 10px rgba(239, 68, 68, 0.5)',
                }}
              />
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="border border-yellow-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg"
            style={{
              boxShadow: '0 0 20px rgba(234, 179, 8, 0.1)',
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-yellow-400" />
                <span className="text-slate-300 font-medium">Level</span>
              </div>
              <span className="text-2xl font-bold text-yellow-400">{gameState.level}</span>
            </div>
            <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-yellow-600 to-yellow-400"
                initial={{ width: 0 }}
                animate={{ width: `${expProgress}%` }}
                style={{
                  boxShadow: '0 0 10px rgba(234, 179, 8, 0.5)',
                }}
              />
            </div>
            <div className="mt-2 text-xs text-slate-400">
              EXP: {gameState.exp}/{expNeeded}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="border border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg"
            style={{
              boxShadow: '0 0 20px rgba(6, 182, 212, 0.1)',
            }}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-cyan-400" />
                <span className="text-slate-300 font-medium">Quests Complete</span>
              </div>
              <span className="text-2xl font-bold text-cyan-400">
                {gameState.quests.filter((q) => q.completed).length}/{gameState.quests.length}
              </span>
            </div>
          </motion.div>
        </div>

        {/* Arise Feature */}
        <AriseFeature
          availableArisePoints={gameState.arisePoints}
          onActivateArise={handleActivateArise}
          activeAriseBuff={gameState.activeAriseBuff}
        />

        {/* Job System */}
        <JobSystem
          currentJob={gameState.currentJob}
          playerLevel={gameState.level}
          totalQuestsCompleted={gameState.totalQuestsCompleted}
          onChangeJob={handleChangeJob}
        />

        {/* Boss Battles */}
        <BossBattle
          bosses={gameState.bosses}
          playerLevel={gameState.level}
          playerStats={gameState.stats}
          equippedItems={gameState.equippedItems}
          onDefeatBoss={handleDefeatBoss}
        />

        {/* Inventory */}
        <Inventory
          items={gameState.inventory}
          equippedItems={gameState.equippedItems}
          onEquipItem={handleEquipItem}
          onUnequipItem={handleUnequipItem}
          onDeleteItem={handleDeleteItem}
        />

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Quests */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-cyan-400" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                DAILY QUESTS
              </h2>
              <button
                onClick={() => {
                  setGameState((prev) => ({
                    ...prev,
                    quests: initialQuests,
                  }));
                }}
                className="p-2 hover:bg-cyan-500/10 rounded-lg transition-colors"
                title="Reset Quests (for testing)"
              >
                <RefreshCw className="w-4 h-4 text-cyan-400" />
              </button>
            </div>
            <QuestList
              quests={gameState.quests}
              onCapturePhoto={handleCapturePhoto}
              onCompleteQuest={handleCompleteQuest}
            />
          </div>

          {/* Stats */}
          <div>
            <StatsDisplay
              stats={gameState.stats}
              availablePoints={gameState.availablePoints}
              onAddStat={handleAddStat}
            />
          </div>
        </div>

        {/* Footer Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="border border-cyan-500/20 bg-slate-900/30 backdrop-blur-sm p-4 rounded-lg"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-slate-400">
            <div>
              <h3 className="text-cyan-400 font-semibold mb-2">System Rules:</h3>
              <ul className="space-y-1 list-disc list-inside">
                <li>Complete quests daily to earn points and EXP</li>
                <li>Incomplete quests result in -20 HP penalty</li>
                <li>Level up to gain stat points</li>
                <li>HP reaching 0 locks system access</li>
              </ul>
            </div>
            <div>
              <h3 className="text-cyan-400 font-semibold mb-2">Arise System:</h3>
              <ul className="space-y-1 list-disc list-inside">
                <li>Earn 10 Arise Points per completed quest</li>
                <li>Activate powerful buffs for 24 hours</li>
                <li>Shadow Extraction: +25% all stats</li>
                <li>Monarch's Domain: No HP penalties</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>

      <CameraCapture
        isOpen={cameraOpen}
        onClose={() => setCameraOpen(false)}
        onCapture={handlePhotoCapture}
      />
    </div>
  );
}

export default App;
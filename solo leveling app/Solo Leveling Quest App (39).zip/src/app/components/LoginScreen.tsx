import { useState } from 'react';
import { motion } from 'motion/react';
import { User, Lock, LogIn } from 'lucide-react';

interface LoginScreenProps {
  onLogin: (username: string, password: string) => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isCreatingAccount, setIsCreatingAccount] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim() && password.trim()) {
      onLogin(username.trim(), password.trim());
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 text-white flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md"
      >
        {/* Header */}
        <div className="text-center mb-8">
          <motion.h1
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 mb-3"
            style={{
              fontFamily: 'Orbitron, sans-serif',
              textShadow: '0 0 40px rgba(6, 182, 212, 0.5)',
            }}
          >
            SOLO LEVELING
          </motion.h1>
          <p className="text-slate-400" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            {isCreatingAccount ? 'Create Your Hunter Account' : 'Hunter Login System'}
          </p>
        </div>

        {/* Login Form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="border-2 border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm rounded-lg p-8"
          style={{
            boxShadow: '0 0 40px rgba(6, 182, 212, 0.2)',
          }}
        >
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Username */}
            <div>
              <label className="block text-sm font-medium text-cyan-400 mb-2">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4" />
                  <span>Username</span>
                </div>
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 bg-slate-800/50 border border-cyan-500/30 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                placeholder="Enter your username"
                required
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-sm font-medium text-cyan-400 mb-2">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  <span>Password</span>
                </div>
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 bg-slate-800/50 border border-cyan-500/30 rounded-lg text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                placeholder="Enter your password"
                required
              />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full px-6 py-4 bg-cyan-500 hover:bg-cyan-600 rounded-lg font-bold text-lg transition-all"
              style={{
                boxShadow: '0 0 30px rgba(6, 182, 212, 0.5)',
                fontFamily: 'Orbitron, sans-serif',
              }}
            >
              <div className="flex items-center justify-center gap-2">
                <LogIn className="w-5 h-5" />
                <span>{isCreatingAccount ? 'CREATE ACCOUNT' : 'LOGIN'}</span>
              </div>
            </button>
          </form>

          {/* Toggle Mode */}
          <div className="mt-6 text-center">
            <button
              onClick={() => setIsCreatingAccount(!isCreatingAccount)}
              className="text-sm text-cyan-400 hover:text-cyan-300 transition-colors"
            >
              {isCreatingAccount
                ? 'Already have an account? Login'
                : "Don't have an account? Create one"}
            </button>
          </div>

          {/* Info */}
          <div className="mt-6 p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
            <p className="text-xs text-cyan-300 text-center">
              Your progress will be saved locally. Use any username/password to get started!
            </p>
          </div>
        </motion.div>

        {/* System Message */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
          className="mt-6 text-center"
        >
          <p className="text-sm text-slate-500">
            [SYSTEM MESSAGE]: Only those chosen by the system may enter...
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}

import { motion } from 'motion/react';
import { Skull } from 'lucide-react';

interface DeathScreenProps {
  onReset: () => void;
}

export function DeathScreen({ onReset }: DeathScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="fixed inset-0 bg-black z-50 flex items-center justify-center"
    >
      <div className="text-center space-y-8">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.3, type: 'spring' }}
        >
          <Skull className="w-32 h-32 text-red-500 mx-auto mb-6" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="space-y-4"
        >
          <h1
            className="text-6xl font-black text-red-500"
            style={{
              fontFamily: 'Orbitron, sans-serif',
              textShadow: '0 0 30px rgba(239, 68, 68, 0.8)',
            }}
          >
            PLAYER DECEASED
          </h1>
          <p className="text-2xl text-red-400" style={{ fontFamily: 'Rajdhani, sans-serif' }}>
            Your HP has reached zero
          </p>
          <p className="text-slate-400 max-w-md mx-auto">
            You have failed to maintain your duties. The system has revoked your access.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="space-y-3"
        >
          <p className="text-cyan-400 text-sm">Do you wish to reset and try again?</p>
          <button
            onClick={onReset}
            className="px-8 py-4 bg-red-600 hover:bg-red-700 rounded-lg font-bold text-lg transition-all"
            style={{
              boxShadow: '0 0 30px rgba(239, 68, 68, 0.6)',
              fontFamily: 'Orbitron, sans-serif',
            }}
          >
            RESET SYSTEM
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}

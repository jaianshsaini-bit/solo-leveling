
  # Solo Leveling Quest App

  This is a code bundle for Solo Leveling Quest App. The original project is available at https://www.figma.com/design/kTmqN7tVBBY7LwzQl6450E/Solo-Leveling-Quest-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
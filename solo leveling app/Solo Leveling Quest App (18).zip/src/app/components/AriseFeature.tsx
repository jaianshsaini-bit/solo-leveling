import { motion, AnimatePresence } from 'motion/react';
import { Zap, Shield, Swords, X } from 'lucide-react';
import { useState } from 'react';

interface AriseFeatureProps {
  availableArisePoints: number;
  onActivateArise: (type: 'shadow' | 'soldier' | 'monarch') => void;
  activeAriseBuff: string | null;
}

const ariseAbilities = [
  {
    id: 'shadow',
    name: 'Shadow Extraction',
    description: 'Boost all stats by 25% for 24 hours',
    cost: 100,
    icon: Shield,
    color: 'purple',
  },
  {
    id: 'soldier',
    name: 'Soldier\'s Will',
    description: 'Double quest rewards for 24 hours',
    cost: 150,
    icon: Swords,
    color: 'blue',
  },
  {
    id: 'monarch',
    name: 'Monarch\'s Domain',
    description: 'No HP penalty for failed quests (24 hours)',
    cost: 200,
    icon: Zap,
    color: 'gold',
  },
];

export function AriseFeature({ availableArisePoints, onActivateArise, activeAriseBuff }: AriseFeatureProps) {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setShowModal(true)}
        className="w-full relative overflow-hidden border-2 border-purple-500/50 bg-gradient-to-r from-purple-900/30 to-blue-900/30 backdrop-blur-sm p-6 rounded-lg group"
        style={{
          boxShadow: '0 0 30px rgba(168, 85, 247, 0.3)',
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-purple-500/20 rounded-lg">
              <Zap className="w-8 h-8 text-purple-400" />
            </div>
            <div className="text-left">
              <h2
                className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 mb-1"
                style={{ fontFamily: 'Orbitron, sans-serif' }}
              >
                ARISE
              </h2>
              <p className="text-sm text-slate-400">Activate special abilities</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-purple-400">{availableArisePoints}</div>
            <div className="text-xs text-slate-400">Arise Points</div>
          </div>
        </div>

        {activeAriseBuff && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-4 p-3 bg-purple-500/10 rounded-lg border border-purple-500/30"
          >
            <p className="text-sm text-purple-300 font-semibold">
              Active Buff: {activeAriseBuff}
            </p>
          </motion.div>
        )}
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-purple-500/30 rounded-lg p-6 max-w-2xl w-full"
              style={{
                boxShadow: '0 0 50px rgba(168, 85, 247, 0.4)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2
                  className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400"
                  style={{ fontFamily: 'Orbitron, sans-serif' }}
                >
                  ARISE ABILITIES
                </h2>
                <button
                  onClick={() => setShowModal(false)}
                  className="p-2 hover:bg-purple-500/10 rounded-lg transition-colors"
                >
                  <X className="w-6 h-6 text-purple-400" />
                </button>
              </div>

              <div className="mb-6 p-4 bg-purple-500/10 rounded-lg border border-purple-500/30">
                <div className="flex items-center justify-between">
                  <span className="text-slate-300">Available Arise Points:</span>
                  <span className="text-2xl font-bold text-purple-400">{availableArisePoints}</span>
                </div>
              </div>

              <div className="space-y-4">
                {ariseAbilities.map((ability) => {
                  const Icon = ability.icon;
                  const canAfford = availableArisePoints >= ability.cost;

                  return (
                    <motion.div
                      key={ability.id}
                      whileHover={canAfford ? { scale: 1.02 } : {}}
                      className={`p-4 rounded-lg border-2 ${
                        canAfford
                          ? 'border-purple-500/50 bg-slate-800/50'
                          : 'border-slate-700/50 bg-slate-800/30 opacity-50'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className={`p-3 rounded-lg ${
                            ability.color === 'purple' ? 'bg-purple-500/20' :
                            ability.color === 'blue' ? 'bg-blue-500/20' :
                            'bg-yellow-500/20'
                          }`}>
                            <Icon className={`w-6 h-6 ${
                              ability.color === 'purple' ? 'text-purple-400' :
                              ability.color === 'blue' ? 'text-blue-400' :
                              'text-yellow-400'
                            }`} />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-bold text-cyan-100 mb-1">
                              {ability.name}
                            </h3>
                            <p className="text-sm text-slate-400 mb-2">
                              {ability.description}
                            </p>
                            <div className="text-sm font-semibold text-purple-400">
                              Cost: {ability.cost} Points
                            </div>
                          </div>
                        </div>
                        <button
                          onClick={() => {
                            if (canAfford) {
                              onActivateArise(ability.id as 'shadow' | 'soldier' | 'monarch');
                              setShowModal(false);
                            }
                          }}
                          disabled={!canAfford}
                          className="px-6 py-2 bg-purple-500 hover:bg-purple-600 disabled:bg-slate-700 disabled:cursor-not-allowed rounded-lg font-medium transition-colors"
                          style={canAfford ? {
                            boxShadow: '0 0 20px rgba(168, 85, 247, 0.5)',
                          } : {}}
                        >
                          Activate
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>

              <div className="mt-6 p-4 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
                <p className="text-xs text-cyan-300">
                  <strong>Note:</strong> Arise Points are earned by completing quests consistently. 
                  Each completed quest grants 10 Arise Points.
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

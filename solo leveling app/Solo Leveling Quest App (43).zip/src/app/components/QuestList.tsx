import { Camera, CheckCircle, XCircle, Dumbbell, Apple, Book, Zap } from 'lucide-react';
import { motion } from 'motion/react';

export interface Quest {
  id: string;
  title: string;
  description: string;
  type: 'exercise' | 'nutrition' | 'learning' | 'other';
  points: number;
  completed: boolean;
  verified: boolean;
  photoProof?: string;
}

interface QuestListProps {
  quests: Quest[];
  onCapturePhoto: (questId: string) => void;
  onCompleteQuest: (questId: string) => void;
}

const questIcons = {
  exercise: Dumbbell,
  nutrition: Apple,
  learning: Book,
  other: Zap,
};

export function QuestList({ quests, onCapturePhoto, onCompleteQuest }: QuestListProps) {
  return (
    <div className="space-y-3">
      {quests.map((quest, index) => {
        const Icon = questIcons[quest.type];
        return (
          <motion.div
            key={quest.id}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative border border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm p-4 rounded-lg"
            style={{
              boxShadow: '0 0 20px rgba(6, 182, 212, 0.1)',
            }}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                <div className="p-2 bg-cyan-500/10 rounded-lg">
                  <Icon className="w-5 h-5 text-cyan-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-cyan-100 mb-1">{quest.title}</h3>
                  <p className="text-sm text-slate-400 mb-2">{quest.description}</p>
                  <div className="flex items-center gap-2 text-xs">
                    <span className="text-cyan-400">+{quest.points} Points</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {quest.completed ? (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="flex items-center gap-1 bg-green-500/20 px-3 py-1.5 rounded-lg"
                  >
                    <CheckCircle className="w-4 h-4 text-green-400" />
                    <span className="text-xs text-green-400 font-medium">Complete</span>
                  </motion.div>
                ) : (
                  <>
                    <button
                      onClick={() => onCapturePhoto(quest.id)}
                      className="p-2 bg-cyan-500/10 hover:bg-cyan-500/20 rounded-lg transition-colors border border-cyan-500/30"
                    >
                      <Camera className="w-4 h-4 text-cyan-400" />
                    </button>
                    {quest.photoProof && (
                      <button
                        onClick={() => onCompleteQuest(quest.id)}
                        className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-600 rounded-lg transition-colors text-xs font-medium"
                        style={{
                          boxShadow: '0 0 15px rgba(6, 182, 212, 0.5)',
                        }}
                      >
                        Verify
                      </button>
                    )}
                  </>
                )}
              </div>
            </div>

            {quest.photoProof && !quest.completed && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                className="mt-3 pt-3 border-t border-cyan-500/20"
              >
                <img
                  src={quest.photoProof}
                  alt="Quest proof"
                  className="w-full h-32 object-cover rounded-lg border border-cyan-500/30"
                />
              </motion.div>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}

import { motion } from 'motion/react';
import { Plus } from 'lucide-react';

export interface PlayerStats {
  strength: number;
  agility: number;
  vitality: number;
  intelligence: number;
  sense: number;
}

interface StatsDisplayProps {
  stats: PlayerStats;
  availablePoints: number;
  onAddStat: (stat: keyof PlayerStats) => void;
}

export function StatsDisplay({ stats, availablePoints, onAddStat }: StatsDisplayProps) {
  const statEntries = Object.entries(stats) as [keyof PlayerStats, number][];

  return (
    <div className="border border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg"
      style={{
        boxShadow: '0 0 20px rgba(6, 182, 212, 0.1)',
      }}
    >
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-cyan-400" style={{ fontFamily: 'Orbitron, sans-serif' }}>
          STATS
        </h2>
        <div className="px-4 py-1.5 bg-cyan-500/20 rounded-lg border border-cyan-500/40">
          <span className="text-sm text-cyan-300 font-semibold">
            Available Points: {availablePoints}
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {statEntries.map(([statName, value]) => (
          <motion.div
            key={statName}
            className="flex items-center justify-between p-3 bg-slate-800/50 rounded-lg border border-cyan-500/20"
            whileHover={{ borderColor: 'rgba(6, 182, 212, 0.5)' }}
          >
            <div className="flex items-center gap-3 flex-1">
              <span className="text-cyan-100 font-medium capitalize w-32">
                {statName}
              </span>
              <div className="flex-1 h-2 bg-slate-700 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-cyan-600 to-cyan-400"
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.min((value / 100) * 100, 100)}%` }}
                  transition={{ duration: 0.5 }}
                  style={{
                    boxShadow: '0 0 10px rgba(6, 182, 212, 0.5)',
                  }}
                />
              </div>
              <span className="text-cyan-400 font-bold text-lg w-12 text-right">
                {value}
              </span>
            </div>
            <button
              onClick={() => onAddStat(statName)}
              disabled={availablePoints === 0}
              className="ml-3 p-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 disabled:opacity-30 disabled:cursor-not-allowed rounded-lg transition-colors border border-cyan-500/40"
            >
              <Plus className="w-4 h-4 text-cyan-400" />
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

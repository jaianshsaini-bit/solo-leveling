import { motion, AnimatePresence } from 'motion/react';
import { Backpack, X, Trash2 } from 'lucide-react';
import { useState } from 'react';
import { Item } from '../data/bosses';

interface InventoryProps {
  items: Item[];
  equippedItems: { [key: string]: Item | null };
  onEquipItem: (item: Item) => void;
  onUnequipItem: (slot: string) => void;
  onDeleteItem: (itemId: string) => void;
}

export function Inventory({ items, equippedItems, onEquipItem, onUnequipItem, onDeleteItem }: InventoryProps) {
  const [showModal, setShowModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Item | null>(null);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-slate-400 border-slate-500/30';
      case 'rare': return 'text-blue-400 border-blue-500/50';
      case 'epic': return 'text-purple-400 border-purple-500/50';
      case 'legendary': return 'text-yellow-400 border-yellow-500/70';
      default: return 'text-slate-400 border-slate-500/30';
    }
  };

  const getRarityGlow = (rarity: string) => {
    switch (rarity) {
      case 'common': return '0 0 10px rgba(148, 163, 184, 0.3)';
      case 'rare': return '0 0 15px rgba(59, 130, 246, 0.4)';
      case 'epic': return '0 0 20px rgba(168, 85, 247, 0.5)';
      case 'legendary': return '0 0 30px rgba(234, 179, 8, 0.6)';
      default: return 'none';
    }
  };

  const isEquipped = (item: Item) => {
    return Object.values(equippedItems).some((equipped) => equipped?.id === item.id);
  };

  const totalStats = () => {
    const stats = { strength: 0, agility: 0, vitality: 0, intelligence: 0, sense: 0 };
    Object.values(equippedItems).forEach((item) => {
      if (item?.stats) {
        Object.entries(item.stats).forEach(([key, value]) => {
          stats[key as keyof typeof stats] += value || 0;
        });
      }
    });
    return stats;
  };

  const equipped = totalStats();

  return (
    <>
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setShowModal(true)}
        className="w-full border border-cyan-500/30 bg-slate-900/50 backdrop-blur-sm p-6 rounded-lg relative"
        style={{
          boxShadow: '0 0 20px rgba(6, 182, 212, 0.1)',
        }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-cyan-500/20 rounded-lg">
              <Backpack className="w-8 h-8 text-cyan-400" />
            </div>
            <div className="text-left">
              <h2 className="text-2xl font-bold text-cyan-400" style={{ fontFamily: 'Orbitron, sans-serif' }}>
                INVENTORY
              </h2>
              <p className="text-sm text-slate-400">Store your boss items</p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-cyan-400">{items.length}</div>
            <div className="text-xs text-slate-400">Items</div>
          </div>
        </div>

        {Object.values(equippedItems).some(item => item) && (
          <div className="mt-4 p-3 bg-cyan-500/10 rounded-lg border border-cyan-500/30">
            <div className="text-xs text-cyan-400 font-semibold mb-2">EQUIPMENT BONUS</div>
            <div className="grid grid-cols-5 gap-2 text-xs">
              {Object.entries(equipped).map(([stat, value]) => (
                value > 0 && (
                  <div key={stat} className="text-center">
                    <div className="text-green-400 font-bold">+{value}</div>
                    <div className="text-slate-400 capitalize">{stat.slice(0, 3)}</div>
                  </div>
                )
              ))}
            </div>
          </div>
        )}
      </motion.button>

      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => {
              setShowModal(false);
              setSelectedItem(null);
            }}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border-2 border-cyan-500/30 rounded-lg p-6 max-w-5xl w-full max-h-[90vh] overflow-y-auto"
              style={{
                boxShadow: '0 0 50px rgba(6, 182, 212, 0.4)',
              }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2
                  className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400"
                  style={{ fontFamily: 'Orbitron, sans-serif' }}
                >
                  INVENTORY
                </h2>
                <button
                  onClick={() => {
                    setShowModal(false);
                    setSelectedItem(null);
                  }}
                  className="p-2 hover:bg-cyan-500/10 rounded-lg transition-colors"
                >
                  <X className="w-6 h-6 text-cyan-400" />
                </button>
              </div>

              {/* Equipped Items */}
              <div className="mb-6">
                <h3 className="text-lg font-bold text-cyan-400 mb-3">EQUIPPED</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {['weapon', 'armor', 'accessory'].map((slot) => {
                    const item = equippedItems[slot];
                    return (
                      <div
                        key={slot}
                        className={`p-4 rounded-lg border-2 ${
                          item ? getRarityColor(item.rarity) : 'border-slate-700/50 bg-slate-800/30'
                        }`}
                        style={item ? { boxShadow: getRarityGlow(item.rarity) } : {}}
                      >
                        <div className="text-xs text-slate-500 uppercase mb-2">{slot}</div>
                        {item ? (
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl">{item.icon}</span>
                                <span className="font-bold">{item.name}</span>
                              </div>
                              <button
                                onClick={() => onUnequipItem(slot)}
                                className="p-1 hover:bg-red-500/20 rounded transition-colors"
                              >
                                <X className="w-4 h-4 text-red-400" />
                              </button>
                            </div>
                            {item.stats && (
                              <div className="text-xs space-y-0.5">
                                {Object.entries(item.stats).map(([stat, value]) => (
                                  <div key={stat} className="flex justify-between">
                                    <span className="text-slate-400 capitalize">{stat}:</span>
                                    <span className="text-green-400">+{value}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        ) : (
                          <div className="text-center text-slate-600 py-4">Empty</div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Inventory Items */}
              <div>
                <h3 className="text-lg font-bold text-cyan-400 mb-3">BACKPACK ({items.length})</h3>
                {items.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <Backpack className="w-16 h-16 mx-auto mb-4 opacity-20" />
                    <p>No items yet. Defeat bosses to earn legendary loot!</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {items.map((item) => (
                      <motion.div
                        key={item.id}
                        whileHover={{ scale: 1.02 }}
                        className={`p-4 rounded-lg border-2 ${getRarityColor(item.rarity)} ${
                          isEquipped(item) ? 'bg-cyan-500/10' : 'bg-slate-800/50'
                        } cursor-pointer`}
                        style={{
                          boxShadow: getRarityGlow(item.rarity),
                        }}
                        onClick={() => setSelectedItem(item)}
                      >
                        <div className="flex items-start justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className="text-3xl">{item.icon}</span>
                            <div>
                              <div className="font-bold text-sm">{item.name}</div>
                              <div className="text-xs text-slate-500 uppercase">{item.rarity}</div>
                            </div>
                          </div>
                          {isEquipped(item) && (
                            <div className="text-xs bg-cyan-500 px-2 py-1 rounded">Equipped</div>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mb-2">{item.description}</p>
                        {item.stats && (
                          <div className="text-xs space-y-0.5">
                            {Object.entries(item.stats).map(([stat, value]) => (
                              <div key={stat} className="flex justify-between">
                                <span className="text-slate-400 capitalize">{stat}:</span>
                                <span className="text-green-400">+{value}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </motion.div>
                    ))}
                  </div>
                )}
              </div>

              {/* Item Actions */}
              {selectedItem && !isEquipped(selectedItem) && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 p-4 bg-cyan-500/20 border-2 border-cyan-500/50 rounded-lg"
                >
                  <p className="text-center text-cyan-100 mb-3">
                    <strong>{selectedItem.name}</strong>
                  </p>
                  <div className="flex gap-3">
                    <button
                      onClick={() => {
                        onEquipItem(selectedItem);
                        setSelectedItem(null);
                      }}
                      className="flex-1 px-6 py-3 bg-cyan-500 hover:bg-cyan-600 rounded-lg font-bold transition-colors"
                      style={{
                        boxShadow: '0 0 20px rgba(6, 182, 212, 0.5)',
                        fontFamily: 'Orbitron, sans-serif',
                      }}
                    >
                      EQUIP
                    </button>
                    <button
                      onClick={() => {
                        onDeleteItem(selectedItem.id);
                        setSelectedItem(null);
                      }}
                      className="px-6 py-3 bg-red-600 hover:bg-red-700 rounded-lg font-bold transition-colors"
                      style={{ fontFamily: 'Orbitron, sans-serif' }}
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
